var APP_DATA = {
  "scenes": [
    {
      "id": "0-hall-du-rez-de-chausse",
      "name": "Hall du rez-de-chaussée",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -1.320960903842554,
        "pitch": 0.08518946232140756,
        "fov": 1.5237402180029125
      },
      "linkHotspots": [
        {
          "yaw": -0.946893515696086,
          "pitch": 0.07928286049328825,
          "rotation": 0,
          "target": "2-foyer-des-lves"
        },
        {
          "yaw": 1.9202534681650203,
          "pitch": 0.10370987798618003,
          "rotation": 5.497787143782138,
          "target": "3-escalier-sud"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -3.0922914232010186,
          "pitch": 0.040940884907161745,
          "title": "Services administratif",
          "text": "Ce couloir mène à l'adminsitration du collège."
        },
        {
          "yaw": -2.2164318246731938,
          "pitch": 0.0021798561014971796,
          "title": "Hall du rez-de-chaussée",
          "text": "Ce hall mène vers la cours de récréation."
        }
      ]
    },
    {
      "id": "1-espace-webradio",
      "name": "Espace webradio",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -0.3074366102469206,
        "pitch": 0.1483346800020282,
        "fov": 1.5237402180029125
      },
      "linkHotspots": [
        {
          "yaw": -2.9665226434552423,
          "pitch": 0.05263605088072332,
          "rotation": 0,
          "target": "2-foyer-des-lves"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.00020545960938456176,
          "pitch": 0.20240105345130388,
          "title": "Matériel de WebRadio",
          "text": "Cette salle est dédiée à la WebRadio du collège et accueillera bientôt également une WebTv."
        },
        {
          "yaw": 2.2416027002380234,
          "pitch": 0.05575743088148499,
          "title": "Salle informatique",
          "text": "Cette porte mène à la salle informatique."
        }
      ]
    },
    {
      "id": "2-foyer-des-lves",
      "name": "Foyer des élèves",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 1.6476536033312899,
        "pitch": 0.13464996522237982,
        "fov": 1.5237402180029125
      },
      "linkHotspots": [
        {
          "yaw": 1.867019744090209,
          "pitch": 0.03882237845473213,
          "rotation": 1.5707963267948966,
          "target": "1-espace-webradio"
        },
        {
          "yaw": -1.6204311639378854,
          "pitch": 0.010438091839386487,
          "rotation": 0,
          "target": "0-hall-du-rez-de-chausse"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.8809979278348266,
          "pitch": 0.041586073381587596,
          "title": "Salle informatique",
          "text": "Cette porte mène à la salle informatique."
        },
        {
          "yaw": -0.07828654794151291,
          "pitch": -0.02898345745003894,
          "title": "Foyer des élèves",
          "text": "Vous êtes ici dans le foyer des élèves qui sert pour des actions diverses et exceptionnellement pour des cours."
        }
      ]
    },
    {
      "id": "3-escalier-sud",
      "name": "Escalier sud",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.3984755977866712,
        "pitch": 0.18179634924871202,
        "fov": 1.5237402180029125
      },
      "linkHotspots": [
        {
          "yaw": -0.1686123786721634,
          "pitch": -0.23993185542362205,
          "rotation": 1.5707963267948966,
          "target": "4-hall-du-1er-tage"
        },
        {
          "yaw": 0.4276451764949112,
          "pitch": 0.3731274413552619,
          "rotation": 1.5707963267948966,
          "target": "0-hall-du-rez-de-chausse"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-hall-du-1er-tage",
      "name": "Hall du 1er étage",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.13564412724948127,
        "pitch": 0.15779833972845836,
        "fov": 1.5237402180029125
      },
      "linkHotspots": [
        {
          "yaw": 1.5620718700356786,
          "pitch": 0.08479881848018067,
          "rotation": 0,
          "target": "5-salle-reunion"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.08710580991960448,
          "pitch": 0.11115912273857376,
          "title": "Couloir du premier étage",
          "text": "Ce couloir mène vers les salles de classe."
        }
      ]
    },
    {
      "id": "5-salle-reunion",
      "name": "Salle réunion",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.022634234060539882,
        "pitch": 0.10684262585781035,
        "fov": 1.5237402180029125
      },
      "linkHotspots": [
        {
          "yaw": 1.7013844690734778,
          "pitch": 0.06333443151679496,
          "rotation": 0,
          "target": "4-hall-du-1er-tage"
        },
        {
          "yaw": -1.9433102483916809,
          "pitch": 0.13587153676786912,
          "rotation": 0,
          "target": "6-balcon-de-la-salle-de-runion"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "6-balcon-de-la-salle-de-runion",
      "name": "Balcon de la salle de réunion",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.8947102016190396,
          "pitch": 0.11494977430355746,
          "rotation": 0,
          "target": "5-salle-reunion"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Visite du collège",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": false
  }
};
